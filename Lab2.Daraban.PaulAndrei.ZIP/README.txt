Programming language: C++
Dev: Visual Studio 2017

This program simulates a compiler by traversing every character of the source code (or text) received as input. This is done in a while loop, in which
we combine characters in a string that are separated by white space, commas or other chars. Then we want to check if the string we have is a keyword, constant,
identifier or comments (which are ignored). The strings will be placed in their respective symbol table and at the end it will be sorted and ready for output.